# Status Report

#### Your name

Nika

#### Your section leader's name

Maxim

#### Project title

Price Calculator

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

I have created a simple version of the calculator with only a few fields, but wrote the logic behind it

#### What have you not done for your project yet?

I have not created all of the fields. Moreover, I haven't created a database where I will save the calculated orders.

#### What problems, if any, have you encountered?

I am not sure how to write javascript code that would show the calculated price on the same html page.
I am also not sure if it is possible to draw data to my program from a constantly updated google sheets file.
Then, I also wondered how to make the entered data when using the calculator to remain intact and if needed cleared.
