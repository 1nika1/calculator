1) In order to visit the website, you'll need to:
    1. Download project.zip
    2. Go to the IDE
    3. Paste project.zip to your directory
    4. In the terminal window, type "unzip project.zip"
    5. cd into the project directory
    6. Run "flask run"
    7. Visit the URL outputted by flask to see the code in action

2) Once you click on the URL, you will see the home page with a simple explanation of what the website does:
    1. Go to the Calculator:
        a) Here you can enter the values for calculation:
            i. paper density
            ii. quantity
            iii. measurements
            ...
        b) Click Calculate button to see the price
        c) Click Place button to place the order

    2. Go to the History page:
        1) Here you can see the previous orders
        2) You can sort by and search for any values

YouTube link: https://youtu.be/Zkts-nK5TdA