To implement my website, I used FLASK because it allowed me to conviniently and efficiently interact with data, querring and passing it from one page
to the other.

The website is created for a printing house manager to make their calculations more convinient. So, the user = the manager.

The Calculator page:
1) To display paper types:
    - I querry the database with paper types and their weights and use a for loop, so I do not have to manualy enter each of them 
    
2) To find current paper price:
    - I get data from a google spreadsheet via XMLHttpRequest(); however, to make sure that the value gets imported before the calculation starts,
      I use update_UI function 
    - I need to use googlespreasheer because the paper price is not frequently updated and in the best case scenario should be altered by the 
      paper seller
    - If the manager would like to update the price, they can access it via the "edit" link)
    - I store the value in in a readonly input field, so it cannot be edited yet its value can be used in my following formulas
    
3) To check the inputs for proper input:
    - I make the rest of the fields of type number, so that other valuesand set a minimum value of 1, so that only positive numbers can be enetered
    - I add required to all inputs
    - Since neither of the validations mentioned above work for a button of type="button," I link the event "click" on calculate with validation 
      of submit function via a functio nested in update_UI()
      
4) To display a calculated price:
    - I create a JavaScript function calculate() that determines the price and displays it near the "Price" cell upon "click" event on "Calculate"
    - I used JavaScript here instead of Python because the value must be outputed to the same webpage
    
5) To place an order:
    - In app.py I create a calculator route with two methods: POST and GET
    - GET just outputs the html page where we do all of the actions mentioned above
    - POST, on the other hand, gets all the data from the html input fields, inserts it into the "history" database, and sends the data from the 
      database to the history.html 
    
    
The History webpage:
1) To alert a user of a newly added order:
    - In calculator route, I add flash(), and in history.html, I add bootstrap alert 
    - It is convinient to notify the manager that everything went successfully 
2) To display the table with data:
    - In the history route, I query history database
    - In history.html, I use for loop and distribute the data from the database to the table 
3) To make table interactive:
    - I use JQuery .DataTable() function with a proper documentation file to be able to sort/search/create pagination
    - It is a super easy and efficient way of having the functions mentioned above 
    
I also utilize layout.html to make my code in the rest of the pages more succinct. Additionally, I use bootstrap and JQuery styling libraries, so I do
not have to create them from a scratch. 