# Proposal

## What will (likely) be the title of your project?

Price Calculator

## In just a sentence or two, summarize your project. (E.g., "A website that lets you buy and sell stocks.")

A webpage that determines the cost of a desired printed product and palces an order.

## In a paragraph or more, detail your project. What will your software do? What features will it have? How will it be executed?

The webpage will allow a customer to choose a type of a product for printing (calendars, invitations, booklets, books, etc.), specify the details for the 
product (quantity, format, colors, lamination, binding, etc.), choose a pick-up date, and place an order if the price is suitable. There is a variety of 
possible printed products and each of them has has its own specific features, so I will have to make multiple webpages to determine the price for each of them.
To implement my project, I will probably use FLASK, and I will need to 
(1) create a database with current prices for paper, ink, salaries
(2) build formulas for proper calculation
(3) make user interface 


## In the world of software, most everything takes longer to implement than you expect. And so it's not uncommon to accomplish less in a fixed amount of time than you hope.

### In a sentence (or list of features), define a GOOD outcome for your final project. I.e., what WILL you accomplish no matter what?

I will create one page which calculates the price of a specific product. The page then can be a template for the rest. 


### In a sentence (or list of features), define a BETTER outcome for your final project. I.e., what do you THINK you can accomplish before the final project's deadline?

I will also create one page, but it will have an additional feature of placing an order. 

### In a sentence (or list of features), define a BEST outcome for your final project. I.e., what do you HOPE to accomplish before the final project's deadline?

I create multiple pages that all can calculate and place an order. 

## In a paragraph or more, outline your next steps. What new skills will you need to acquire? What topics will you need to research? If working with one of two classmates, who will do what?

1) learn the data for printing to fill in my database 
2) understand the logic behind formulas for determining the cost 
3) create user interface 